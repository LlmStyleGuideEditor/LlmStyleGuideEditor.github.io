Download and import the following python packages:

pycrytodome
requests
tkinter

Run the program main.py

The Huggingface API may take some time (3-5 minutes) to boot up when you make a request. Also, when it is running it costs money. 
You must be connected to the internet for the program to function correctly.

All program files must be in the same directory.

The current working directory must be the code directory for the databases access to work correctly.